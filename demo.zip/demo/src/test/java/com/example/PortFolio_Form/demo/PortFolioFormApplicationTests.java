package com.example.PortFolio_Form.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortFolioFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
